package com.example.projetandroid_dg_ba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class Jouer_Activity extends AppCompatActivity {

    private Integer BORNE_HAUTE = 999;
    private Integer reponseElement = 0;
    private Integer premierElement = 0;
    private Integer deuxiemeElement = 0;
    private TextView textViewReponse;
    private TypeOperationEnum typeOperation;
    private TextView textViewEnigme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jouer);
        textViewReponse = findViewById(R.id.textViewReponse);
        textViewEnigme = findViewById(R.id.textViewEnigme);
        textViewReponse.setText("0");
        GenerateRandomEnigme();
        Button bouton1 = findViewById(R.id.bouton_1);
        bouton1.setOnClickListener(view -> ajouteValeur(1));
        Button bouton2 = findViewById(R.id.bouton_2);
        bouton2.setOnClickListener(view -> ajouteValeur(2));
        Button bouton3 = findViewById(R.id.bouton_3);
        bouton3.setOnClickListener(view -> ajouteValeur(3));
        Button bouton4 = findViewById(R.id.bouton_4);
        bouton4.setOnClickListener(view -> ajouteValeur(4));
        Button bouton5 = findViewById(R.id.bouton_5);
        bouton5.setOnClickListener(view -> ajouteValeur(5));
        Button bouton6 = findViewById(R.id.bouton_6);
        bouton6.setOnClickListener(view -> ajouteValeur(6));
        Button bouton7 = findViewById(R.id.bouton_7);
        bouton7.setOnClickListener(view -> ajouteValeur(7));
        Button bouton8 = findViewById(R.id.bouton_8);
        bouton8.setOnClickListener(view -> ajouteValeur(8));
        Button bouton9 = findViewById(R.id.bouton_9);
        bouton9.setOnClickListener(view -> ajouteValeur(9));
        Button bouton0 = findViewById(R.id.bouton_0);
        bouton0.setOnClickListener(view -> ajouteValeur(0));
        Button boutonDel = findViewById(R.id.DelButton);
        boutonDel.setOnClickListener(view -> removeValeur());
        Button boutonMoins = findViewById(R.id.MoinsButton);
        boutonMoins.setOnClickListener(view -> Moins());
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.toolbar,menu);
        MenuItem toolbarRepondre = menu.findItem(R.id.toolbar_repondre);
        MenuItem toolbarNettoyer = menu.findItem(R.id.toolbar_nettoyer);
        MenuItem toolbarRetour = menu.findItem(R.id.toolbar_retour);
        //toolbarRepondre.setOnMenuItemClickListener(menuItem -> calculResultat()); // A FAIRE PLUS TARD
        toolbarNettoyer.setOnMenuItemClickListener(menuItem -> Clear());
        toolbarRetour.setOnMenuItemClickListener(menuItem -> RetourMenu());
        return true;
    }

    private boolean RetourMenu() {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        return true;
    }

    private void GenerateRandomEnigme(){
        int randomNumber1,randomNumber2;
        int Rand = new Random().nextInt(3);
        if(Rand==0) this.typeOperation=TypeOperationEnum.ADD;
        else if(Rand==1) this.typeOperation=TypeOperationEnum.SUBSTRACT;
        else if(Rand==2) this.typeOperation=TypeOperationEnum.MULTIPLY;
        if(this.typeOperation == TypeOperationEnum.MULTIPLY){
            randomNumber1 = new Random().nextInt(11);
            randomNumber2 = new Random().nextInt(11);
        }else{
            randomNumber1 = new Random().nextInt(200)-100;
            randomNumber2 = new Random().nextInt(200)-100;
        }
        premierElement = randomNumber1;
        deuxiemeElement = randomNumber2;
        majTextView();
    }

    private void majTextView() {
        String textAAfficher="";
        if(typeOperation == null){
            textAAfficher = premierElement.toString();
        }else{
            textAAfficher = premierElement.toString() + " "+this.typeOperation.getSymbol()+" "+deuxiemeElement;
        }
        textViewEnigme.setText(textAAfficher);
    }

    private void majTextViewReponse() {
        String textAAfficher="";

        textAAfficher = reponseElement.toString();

        textViewReponse.setText(textAAfficher);
    }

    private boolean Repondre() {
        textViewEnigme.setText("");
        reponseElement=0;
        return true;
    }

    private void ajouteValeur(Integer valeur){

        if(10*reponseElement+valeur > BORNE_HAUTE){
            Toast.makeText(this,getString(R.string.ERREUR_TROP_GRAND),Toast.LENGTH_LONG).show();
        }else{
            reponseElement = 10*reponseElement+valeur;
        }
        majTextViewReponse();
    }

    private void removeValeur(){
        reponseElement = (int) reponseElement / 10;
        majTextViewReponse();
    }

    private void Moins(){
        reponseElement = -reponseElement;
        majTextViewReponse();
    }

    private boolean Clear() {
        textViewReponse.setText("");
        return true;
    }
}