package com.example.projetandroid_dg_ba.entity;

public class BaseEntity {
    public long id;
}
